//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by grehexa.rc
//
#define IDB_BLOCK1                      101
#define IDB_BLOCK2                      102
#define IDB_BLOCK3                      103
#define IDB_BLOCK4                      104
#define IDB_BLOCK5                      105
#define IDB_MASK                        106
#define IDB_BACKGROUND                  108
#define IDB_SB1                         109
#define IDB_SB2                         110
#define IDB_SBM1                        111
#define IDB_SBM2                        112
#define IDC_CURSOR1                     113
#define IDB_BOMB                        114
#define IDB_MASK2                       115
#define IDB_MASK3                       116
#define IDB_MASK4                       117
#define IDB_MASK5                       118
#define IDB_STAR                        119
#define IDB_SBM3                        120
#define IDB_SB3                         121

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        122
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
